/**
 * @author Georgios Romanos
 * @version 1.2
 * The following class is the memory game class that uses resources and action events to make the memory game. Further
 * details for the class are inside the class
 */
package UserInterface;
import BackEnd.*;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;


public class MemoryGameApp {

    /**
     * Locale and ResourceBundle are used to display both english and greek language in the game
     */
    Locale locale;
    ResourceBundle messages;

    /**
     * ImageIcon  is used to create images
     */

    ImageIcon icon;
    int firstDigit;
    int secondDigit;

    /**
     * creates the frame for the game with title "Memory Game"
     */

    private JFrame window = new JFrame("");

    /**
     * The two following JPanel and CardLayout are used to create all basic menu panels, such as main menu, play menu,
     * settings menu and highescores.
     * Found information regarding CardLayout from: https://docs.oracle.com/javase/7/docs/api/java/awt/CardLayout.html
     */

    private JPanel menuPanels = new JPanel();
    private CardLayout menuLayouts = new CardLayout();

    /**
     * All elements of the main menu panel.
     */

    private JPanel mainMenuPanel = new JPanel(new GridLayout(4,1, 0, 10));
    private JLabel MainLabel = new JLabel("", SwingConstants.CENTER);
    private JButton playButton = new JButton();
    private JButton settingsButton = new JButton();
    private JButton highscoresButton = new JButton();

    /**
     * All elements of the play menu panel.
     */

    private JPanel playMenuPanel = new JPanel(new GridLayout(7, 1));
    private JLabel PlayLabel = new JLabel("", SwingConstants.CENTER);
    private JLabel gameModeLabel = new JLabel("", SwingConstants.CENTER);
    private ButtonGroup radioButtonGroupNumOfPlayers = new ButtonGroup();
    private ButtonGroup radioButtonGroupGameMode = new ButtonGroup();
    private JRadioButton twoPlayersButton = new JRadioButton();
    private JRadioButton threePlayersButton = new JRadioButton();
    private JRadioButton fourPlayersButton = new JRadioButton();
    private JRadioButton gameModeOneButton = new JRadioButton();
    private JRadioButton gameModeTwoButton = new JRadioButton();
    private JRadioButton gameModeThreeButton = new JRadioButton();
    private JButton singlePlayerButton = new JButton();
    private JButton oneOnOneButton = new JButton();
    private JButton customModeButton = new JButton();
    private JButton returnToMainMenuButton1 = new JButton();

    /**
     * All elements of the settings panel.
     */

    private JPanel settingsMenuPanel = new JPanel(new GridLayout(5, 1));
    private JLabel SettingsLabel = new JLabel("" , SwingConstants.CENTER);
    private JLabel setLanguageLabel = new JLabel();
    private JLabel openCardDurationLabel = new JLabel();
    private JLabel cardSleevesLabel = new JLabel();
    private ButtonGroup radioButtonGroupLanguages = new ButtonGroup();
    private ButtonGroup radioButtonGroupDurations = new ButtonGroup();
    private ButtonGroup radioButtonGroupSleeves = new ButtonGroup();
    private JRadioButton languageToGreekButton = new JRadioButton("Ελληνικά");
    private JRadioButton languageToEnglishButton = new JRadioButton("English");
    private JRadioButton languageToJapaneseButton = new JRadioButton("日本語");
    private JRadioButton durationToOneSecondButton = new JRadioButton("1''");
    private JRadioButton durationToThreeSecondsButton = new JRadioButton("3''");
    private JRadioButton durationToFiveSecondsButton = new JRadioButton("5''");
    private JRadioButton redSleevesButton = new JRadioButton();
    private JRadioButton blueSleevesButton = new JRadioButton();
    private JButton returnToMainMenuButton2 = new JButton();

    /**
     * All elements of the highscores panel.
     */

    private JPanel highscoreMenuPanel = new JPanel(new BorderLayout());
    private JLabel[][] highscoreLabel;
    private JButton returnToMainMenuButton3 = new JButton();

    /**
     * All elements of the panel responsible for setting players.
     */

    private JPanel setPlayerPanel = new JPanel(new GridLayout(4, 1));
    private JLabel playerLabel = new JLabel("", SwingConstants.CENTER);
    private JLabel setPlayerNameLabel = new JLabel("", SwingConstants.CENTER);
    private TextField setPlayerNameTextField = new TextField();
    private ButtonGroup playerType = new ButtonGroup();
    private JRadioButton human = new JRadioButton();
    private JRadioButton goldfish = new JRadioButton();
    private JRadioButton kangaroo = new JRadioButton();
    private JRadioButton elephant = new JRadioButton();
    private JButton goBack = new JButton();
    private JButton goAhead = new JButton();

    /**
     * Timer is class which can be used to stall some game actions to play the memory game properly. I found information
     * about that class in the link below:
     * https://stackoverflow.com/questions/14106953/swing-thread-sleep-stop-jtextfield-settext-working
     */

    private Timer timer;
    private Timer startingStall;

    /**
     * usable Action Listeners
     */

    ActionListener compareCards;

    /**
     * usable variables regarding creating memory game basic information
     */
    private boolean exitedGame;
    private Player[] Player;
    private Board Board;
    private Duel_Board DuelBoard;
    private int boardType;
    private String[] name;
    private int[] playerKind;
    private int numOfPlayers;
    private int currentPlayer;
    private int rows;
    private int columns;
    private int cardsOfSameCopy;
    private int gameType;
    private int selectedCardOrder;
    private int cardPicks[][];
    private boolean isPlayerPicking;
    private int /*open card*/ duration;
    private char primarySleeve;
    private char secondarySleeve;
    private int idPickedLast;

    /**
     * all elements to create the memory game frame:
     */

    private JFrame game;
    private JPanel gamePanel;
    private JPanel cardPanel;
    private Card[][] table;
    private JLabel[][] card;
    private JLabel[][] playerInfo;
    private JLabel informationLabel;
    private JButton exitButton;
    private JButton playAgainButton;

    /**
     * Constructor of Memory Game
     */

    public MemoryGameApp(){
        numOfPlayers = 2;
        boardType = 1;
        duration = 3;
        primarySleeve = 'A';
        secondarySleeve = 'B';
        window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        window.setResizable(false);
        menuPanels.setLayout(menuLayouts);
        locale = new Locale("en", "US");
        messages = ResourceBundle.getBundle("I18n.MemoryGameLanguage", locale);
        createMainMenu();
        createPlayMenu();
        createSettingsMenu();
        createSetPlayerMenu();
        createHighscoresMenu();
        setLanguage(messages);
        window.add(menuPanels);
        window.setVisible(true);
        openMainMenu();

    }

    /**
     * void type function that changes the language of the texts of the game between greek and english.
     * @param messages It contains all the messages of the of all static menu panels that need to be translated.
     */

    private void setLanguage(ResourceBundle messages){
            window.setTitle(messages.getString("Memory Game"));
            returnToMainMenuButton1.setText(messages.getString("Return to main menu"));
            returnToMainMenuButton2.setText(messages.getString("Return to main menu"));
            returnToMainMenuButton3.setText(messages.getString("Return to main menu"));
            MainLabel.setText(messages.getString("Welcome to memory game!"));
            playButton.setText(messages.getString("Play"));
            settingsButton.setText(messages.getString("Settings"));
            highscoresButton.setText(messages.getString("Highscores"));
            PlayLabel.setText(messages.getString("Please select one of the following gamemodes:"));
            gameModeLabel.setText(messages.getString("Table:"));
            gameModeOneButton.setText(messages.getString("4x6 - pairs of two cards"));
            gameModeTwoButton.setText(messages.getString("6x8 - pairs of two cards"));
            gameModeThreeButton.setText(messages.getString("6x6 - pairs of three cards"));
            twoPlayersButton.setText("2 " + messages.getString("Players"));
            threePlayersButton.setText("3 " + messages.getString("Players"));
            fourPlayersButton.setText("4 " + messages.getString("Players"));
            singlePlayerButton.setText(messages.getString("Singleplayer"));
            oneOnOneButton.setText(messages.getString("One on One"));
            customModeButton.setText(messages.getString("Custom Mode"));
            SettingsLabel.setText(messages.getString("What do you wish to change?"));
            setLanguageLabel.setText(messages.getString("Change language:"));
            openCardDurationLabel.setText(messages.getString("Face-up card duration:"));
            cardSleevesLabel.setText(messages.getString("Card color:"));
            redSleevesButton.setText(messages.getString("Red"));
            blueSleevesButton.setText(messages.getString("Blue"));
            setPlayerNameLabel.setText(messages.getString("Name (up to 9 letters)") + ":");
            human.setText(messages.getString("Human"));
            goldfish.setText(messages.getString("Goldfish"));
            kangaroo.setText(messages.getString("Kangaroo"));
            elephant.setText(messages.getString("Elephant"));
            goBack.setText(messages.getString("Back"));
            highscoreLabel[0][0].setText(messages.getString("Singleplayer") + " 4x6");
            highscoreLabel[1][0].setText(messages.getString("Singleplayer") + " 6x8");
            highscoreLabel[2][0].setText(messages.getString("Singleplayer") + " 6x6");
            highscoreLabel[3][0].setText(messages.getString("Custom Mode") + " 4x6");
            highscoreLabel[4][0].setText(messages.getString("Custom Mode") + " 6x8");
            highscoreLabel[5][0].setText(messages.getString("Custom Mode") + " 6x6");
            highscoreLabel[6][0].setText(messages.getString("One on One") + " 6x8");


    }

    /**
     * void type function that displays the main menu panel
     */

    private void openMainMenu(){
        window.setSize(300, 200);
        menuLayouts.show(menuPanels, "Main Menu");
    }

    /**
     * void type function that displays the settings menu panel
     */

    private void openSettingsMenu(){
        window.setSize(550, 180);
        menuLayouts.show(menuPanels, "Settings Menu");
    }

    /**
     * void type function that displays the play menu panel
     */

    private void openPlayMenu(){
        enableCPUMode();
        gameModeOneButton.doClick();
        twoPlayersButton.doClick();
        window.setSize(600,200);
        menuLayouts.show(menuPanels, "Play Menu");
    }

    /**
     * void type function that displays the panel that sets the players
     */

    private void openSetPlayerPanel(){
        window.setSize(400, 150);
        menuLayouts.show(menuPanels, "Setting Players Panel");
        currentPlayer = 0;
        renamePlayerLabels();
    }

    /**
     * void type function that displays the Highscore Panel.
     * Note: For any multiplayer mode, it displays the score of the player with the highest amount of wins
     * during his games in any multiplayer gamemode without exiting that game.
     */

    private void openHighscoresMenuPanel(){
        Highscore_File_Manager read = new Highscore_File_Manager();
        Name_and_Score[] highscores;
        highscores = read.Read_Highscores();
        for(int i=0; i< highscores.length; i++){
            highscoreLabel[i][1].setText(highscores[i].getName() + " " + highscores[i].getScore());
        }
        window.setSize(300, 500);
        menuLayouts.show(menuPanels, "Highscore Menu");
    }

    /**
     * void type function that generates the main menu panel
     */

    private void createMainMenu(){
        mainMenuPanel.add(MainLabel);
        mainMenuPanel.add(playButton);
        mainMenuPanel.add(settingsButton);
        mainMenuPanel.add(highscoresButton);
        menuPanels.add(mainMenuPanel, "Main Menu");

        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openPlayMenu();
            }
        });


        settingsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openSettingsMenu();
            }
        });

        highscoresButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openHighscoresMenuPanel();
            }
        });

    }

    /**
     * function that generates the play menu panel. In it, the user can direct themselves in the play menu panel, the
     * settings panel or the highscores panel.
     */

    private void createPlayMenu(){
        radioButtonGroupNumOfPlayers.add(twoPlayersButton);
        radioButtonGroupNumOfPlayers.add(threePlayersButton);
        radioButtonGroupNumOfPlayers.add(fourPlayersButton);
        twoPlayersButton.doClick();

        radioButtonGroupGameMode.add(gameModeOneButton);
        radioButtonGroupGameMode.add(gameModeTwoButton);
        radioButtonGroupGameMode.add(gameModeThreeButton);
        gameModeOneButton.doClick();

        final JPanel gameModeInfo = new JPanel(new GridLayout(1, 3));
        gameModeInfo.add(gameModeOneButton);
        gameModeInfo.add(gameModeTwoButton);
        gameModeInfo.add(gameModeThreeButton);

        final JPanel customModeInfo = new JPanel(new GridLayout(1, 4));
        customModeInfo.add(customModeButton);
        customModeInfo.add(twoPlayersButton);
        customModeInfo.add(threePlayersButton);
        customModeInfo.add(fourPlayersButton);

        playMenuPanel.add(PlayLabel);
        playMenuPanel.add(oneOnOneButton);
        playMenuPanel.add(gameModeLabel);
        playMenuPanel.add(gameModeInfo);
        playMenuPanel.add(singlePlayerButton);
        playMenuPanel.add(customModeInfo);
        playMenuPanel.add(returnToMainMenuButton1);

        menuPanels.add(playMenuPanel, "Play Menu");

        twoPlayersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                numOfPlayers = 2;
            }
        });

        threePlayersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                numOfPlayers = 3;
            }
        });

        fourPlayersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                numOfPlayers = 4;
            }
        });

        gameModeOneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boardType = 1;
            }
        });

        gameModeTwoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boardType = 2;
            }
        });

        gameModeThreeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boardType = 3;
            }
        });

        returnToMainMenuButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openMainMenu();
            }
        });

        singlePlayerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                numOfPlayers = 1;
                disableCPUMode();
                gameType = 1;
                createPlayerData(numOfPlayers);
                openSetPlayerPanel();
            }
        });

        customModeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createPlayerData(numOfPlayers);
                gameType = 2;
                openSetPlayerPanel();
            }
        });

        oneOnOneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                numOfPlayers = 2;
                gameType = 3;
                boardType = 4;
                createPlayerData(numOfPlayers);
                openSetPlayerPanel();
            }
        });

    }


    /**
     * function that generates the settings panel. In this, user can set the game's language and the timer the cards
     * are going to be displayed as face-up after a player's turn.
     */

    private void createSettingsMenu() {
        radioButtonGroupLanguages.add(languageToEnglishButton);
        radioButtonGroupLanguages.add(languageToGreekButton);
        radioButtonGroupLanguages.add(languageToJapaneseButton);
        languageToEnglishButton.doClick();

        radioButtonGroupDurations.add(durationToOneSecondButton);
        radioButtonGroupDurations.add(durationToThreeSecondsButton);
        radioButtonGroupDurations.add(durationToFiveSecondsButton);
        durationToThreeSecondsButton.doClick();

        radioButtonGroupSleeves.add(redSleevesButton);
        radioButtonGroupSleeves.add(blueSleevesButton);
        redSleevesButton.doClick();

        final JPanel setLanguagePanel = new JPanel(new GridLayout(1, 4));
        setLanguagePanel.add(setLanguageLabel);
        setLanguagePanel.add(languageToEnglishButton);
        setLanguagePanel.add(languageToGreekButton);
        setLanguagePanel.add(languageToJapaneseButton);
        languageToEnglishButton.doClick();

        final JPanel openCardDurationRadioGroup = new JPanel(new GridLayout(1, 3));
        openCardDurationRadioGroup.add(durationToOneSecondButton);
        openCardDurationRadioGroup.add(durationToThreeSecondsButton);
        openCardDurationRadioGroup.add(durationToFiveSecondsButton);

        final JPanel openCardDurationPanel = new JPanel(new GridLayout(1,2));
        openCardDurationPanel.add(openCardDurationLabel);
        openCardDurationPanel.add(openCardDurationRadioGroup);

        final JPanel cardSleevePanel = new JPanel(new GridLayout(1, 3));
        cardSleevePanel.add(cardSleevesLabel);
        cardSleevePanel.add(redSleevesButton);
        cardSleevePanel.add(blueSleevesButton);


        settingsMenuPanel.add(SettingsLabel);
        settingsMenuPanel.add(setLanguagePanel);
        settingsMenuPanel.add(openCardDurationPanel);
        settingsMenuPanel.add(cardSleevePanel);
        settingsMenuPanel.add(returnToMainMenuButton2);

        menuPanels.add(settingsMenuPanel, "Settings Menu");

        languageToEnglishButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                locale = new Locale("en", "US");
                messages = ResourceBundle.getBundle("I18n.MemoryGameLanguage", locale);
                setLanguage(messages);
            }
        });

        languageToGreekButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                locale = new Locale("el", "GR");
                messages = ResourceBundle.getBundle("I18n.MemoryGameLanguage", locale);
                setLanguage(messages);
            }
        });

        languageToJapaneseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                locale = new Locale("jp", "JP");
                messages = ResourceBundle.getBundle("I18n.MemoryGameLanguage", locale);
                setLanguage(messages);
            }
        });

        durationToOneSecondButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                duration = 1;
            }
        });

        durationToThreeSecondsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                duration = 3;
            }
        });

        durationToThreeSecondsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                duration = 5;
            }
        });

        redSleevesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                primarySleeve = 'A';
                secondarySleeve = 'B';
            }
        });

        blueSleevesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                primarySleeve = 'B';
                secondarySleeve = 'A';
            }
        });

        returnToMainMenuButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openMainMenu();
            }
        });
    }

    /**
     * function that generates the highscores panel. In it, a player can check the highscores for each mode
     */

    private void createHighscoresMenu(){
        highscoreLabel = new JLabel[7][2];
        JPanel highscoreData = new JPanel(new GridLayout(7, 2, 10 , 5));
        for(int i = 0; i < 7; i++){
            for(int j = 0; j < 2; j++) {
                highscoreLabel[i][j] = new JLabel("");
                highscoreData.add(highscoreLabel[i][j]);
            }
        }
        highscoreLabel[0][0].setText(messages.getString("Singleplayer") + " 4x6");
        highscoreLabel[1][0].setText(messages.getString("Singleplayer") + " 6x8");
        highscoreLabel[2][0].setText(messages.getString("Singleplayer") + " 6x6");
        highscoreLabel[3][0].setText(messages.getString("Custom Mode") + " 4x6");
        highscoreLabel[4][0].setText(messages.getString("Custom Mode") + " 6x8");
        highscoreLabel[5][0].setText(messages.getString("Custom Mode") + " 6x6");
        highscoreLabel[6][0].setText(messages.getString("One on One") + " 6x8");
        highscoreMenuPanel.add(returnToMainMenuButton3, BorderLayout.SOUTH);
        highscoreMenuPanel.add(highscoreData, BorderLayout.CENTER);
        menuPanels.add(highscoreMenuPanel, "Highscore Menu");

        returnToMainMenuButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openMainMenu();
            }
        });
    }

    /**
     * function that creates the panel in which you can set the information of participating players. In this panels
     * helpful functions are being used in action events to create the players and the game board.
     */

    private void createSetPlayerMenu(){
        playerType.add(human);
        playerType.add(goldfish);
        playerType.add(kangaroo);
        playerType.add(elephant);
        human.doClick();
        final JPanel PlayerTypeButtonGroup = new JPanel(new GridLayout(1,4));
        PlayerTypeButtonGroup.add(human);
        PlayerTypeButtonGroup.add(goldfish);
        PlayerTypeButtonGroup.add(kangaroo);
        PlayerTypeButtonGroup.add(elephant);

        final JPanel fullTextFieldPanel = new JPanel(new GridLayout(1, 2));
        fullTextFieldPanel.add(setPlayerNameLabel);
        fullTextFieldPanel.add(setPlayerNameTextField);

        final JPanel proceedings = new JPanel(new GridLayout(1,4 ));
        proceedings.add(goBack);
        proceedings.add(goAhead);

        setPlayerPanel.add(playerLabel);
        setPlayerPanel.add(fullTextFieldPanel);
        setPlayerPanel.add(PlayerTypeButtonGroup);
        setPlayerPanel.add(proceedings);

        menuPanels.add(setPlayerPanel, "Setting Players Panel");

        human.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playerKind[currentPlayer] = 0;
            }
        });

        goldfish.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            playerKind[currentPlayer] = 1;
            }
        });

        kangaroo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              playerKind[currentPlayer] = 2;
            }
        });

        elephant.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playerKind[currentPlayer] = 3;
            }
        });

        goBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentPlayer == 0){
                    openPlayMenu();
                }
                else{
                    currentPlayer--;
                    renamePlayerLabels();
                }
            }
        });

        goAhead.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                name[currentPlayer] = setPlayerNameTextField.getText();
                name[currentPlayer] = name[currentPlayer].trim();
                if(name[currentPlayer].length()>9) {
                    name[currentPlayer].substring(0, 8);
                }
                if(name[currentPlayer].isEmpty() || name[currentPlayer] == ""){
                    name[currentPlayer] = (messages.getString("Player") + " " + (currentPlayer + 1));
                }
                currentPlayer++;
                if(currentPlayer==numOfPlayers){
                    createGameBoard();
                    createPlayers();
                    createGameType(gameType);
                }
                else {
                    renamePlayerLabels();
                }
            }
        });

    }

    /**
     * void function that modifies specific texts regarding which player is being set
     */

    private void renamePlayerLabels(){
        playerLabel.setText(messages.getString("Player") + " " + (currentPlayer + 1) + ":");
        setPlayerNameTextField.setText("");
        human.doClick();
        if((currentPlayer + 1) == numOfPlayers){
            goAhead.setText(messages.getString("Play"));
        }
        else
            goAhead.setText(messages.getString("Next"));

    }

    /**
     * function that creates a board based on gameMode. For gameMode 1 it creates a board of 4x6 cards with 2 cards of
     * the same copy. For gameMode 2 it creates a board of 6x8 cards with 2 cards of the same copy. For gameMode 3 it
     * creates a board of 6x6 cards with 3 cards of the same copy. With 4 cards, it creates a duel_board which is based
     * on the "One on One" mode, in which players use 2 different boards.
     */

    private void createGameBoard(){
        if (boardType==1) {
            Board = new Board(4, 6, 2);
            rows = Board.getRows();
            columns = Board.getColumns();
            cardsOfSameCopy = Board.getSameCopies();
        }
        else if (boardType == 2) {
            Board = new Board(6, 8, 2);
            rows = Board.getRows();
            columns = Board.getColumns();
            cardsOfSameCopy = Board.getSameCopies();
        }
        else if (boardType == 3){
            Board = new Board(6, 6, 3);
            rows = Board.getRows();
            columns = Board.getColumns();
            cardsOfSameCopy = Board.getSameCopies();
        }
        else if (boardType == 4) {
            DuelBoard = new Duel_Board();
            rows = DuelBoard.getRows();
            columns = DuelBoard.getColumns()*2;
            cardsOfSameCopy = 2;
        }

    }

    /**
     * function that disables the option for player to select CPU mode for a player. It's used to not allow the use of
     * CPU in singleplayer mode
     */

    private void disableCPUMode(){
        goldfish.setEnabled(false);
        kangaroo.setEnabled(false);
        elephant.setEnabled(false);
    }

    private void enableCPUMode(){
        goldfish.setEnabled(true);
        kangaroo.setEnabled(true);
        elephant.setEnabled(true);
    }

    /**
     * function that creates the info that is going to be saved on each player information (his name and the type of
     * that player)
     * @param playerAmount is the amount of players are going to play the memory game
     */

    private void createPlayerData(int playerAmount){
        name = new String[playerAmount];
        playerKind = new int[playerAmount];
    }

    /**
     * creates player types of each player according to playerKind of each Player. If playerKind is 0, then that player
     * is human. If playerKind is 1, then that player is CPU goldfish. If playerKind is 2, then that player is CPU
     * Kangaroo. If playerKind is 3, then that player is CPU elephant. CPU also has the duel board saved to manage
     * to pick cards according the type of game and type of the board.
     */

    private void createPlayers() {
        Player = new Player[numOfPlayers];
        for (int i = 0; i < numOfPlayers; i++) {
            if (playerKind[i] == 0) {
                Player[i] = new Human_Player(name[i]);
            } else if (boardType==4) {
                Player[i] = new CPU(name[i], playerKind[i], DuelBoard, i);
            }
            else{
                Player[i] = new CPU(name[i], playerKind[i], Board);
            }
        }
    }

    /**
     * function that displays a specific card in the board
     * @param row is the row of the card the player selected (starting from 0)
     * @param column is the column of the card the player selected (starting from 0)
     */

    private void displayCard(int row, int column) {
        String imageName;
        if(table[row][column]==null){
           card[row][column].setIcon(null);
        }
        else {
            if (!table[row][column].isOpen()) {
                imageName = "Image-" + 0 + "-" + primarySleeve + ".png";
                if(gameType == 3) {
                    if (column >= DuelBoard.getColumns()) {
                        imageName = "Image-" + 0 + "-" + secondarySleeve + ".png";
                    }
                }
            } else {
                int id = table[row][column].getId();
                firstDigit = (id + 1) / 10;
                secondDigit = ((id + 1) % 10);
                imageName = "Image-" + firstDigit + "-" + secondDigit + ".png";
            }
            URL imagePath = getClass().getResource("Images/" + imageName);
            icon = new ImageIcon(imagePath);
            card[row][column].setIcon(icon);
        }
    }

    /**
     * function that displays all cards. It is used at the beginning of each game as to help player get a tiny glance of
     * the cards before choosing. The duration of the card being open depends on the parameter "duration" which can
     * be set in settings menu.
     */
    private void displayAllCards(){
        isPlayerPicking = false;
        if(gameType==3) {
            DuelBoard.openAllCards();
        }
        else{
            Board.openAllCards();
        }
        for(int i = 0; i < rows; i++){
            for(int j = 0; j < columns ; j++)
                displayCard(i, j);
        }
        ActionListener listener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(gameType==3) {
                    DuelBoard.closeAllCards();
                }
                else{
                    Board.closeAllCards();
                }
                for(int i = 0; i < rows; i++){
                    for(int j = 0; j < columns ; j++)
                        displayCard(i, j);
                }
                exitedGame = false;
                if (gameType == 1){
                    updateSinglePlayerGame();
                }
                else if (gameType == 2){
                    updateCustomModeGame();
                }
                else if(gameType == 3){
                    updateOneOnOneGame();
                }
            }
        };

        startingStall = new Timer(duration*1000, listener);
        startingStall.setRepeats(false);
        startingStall.start();
    }

    /**
     * class that opens the appropriate card based on the coordinations the human player clicked their mouse on
     * the cardPanel, following by the game logic of memory game.
     * @param x is the x coordinates the player gave upon mouse click.
     * @param y is the y coordinates the player gave upon mouse click.
     */
    private void findCard(int x, int y) {
        double panelX = ((double) cardPanel.getWidth()) / columns;
        double panelY = ((double) cardPanel.getHeight()) / rows;
        int i, j;
        for (i = 0; i < columns; i++) {
            if (panelX * i > x) {
                break;
            }
        }
        for (j = 0; j < rows; j++) {
            if (panelY * j > y) {
                break;
            }
        }
        i--;
        j--;
        if(gameType!=3){
            if (table[j][i] != null) {
                if (!table[j][i].isOpen()) {
                    idPickedLast = pickCard(j, i);
                    CPUMemorize();
                    selectedCardOrder++;
                }
            }
        }
        else if (DuelBoard.checkBoundaries(currentPlayer, i)){
            if (table[j][i] != null) {
                if (!table[j][i].isOpen()) {
                    isPlayerPicking = false;
                    DuelBoard.setSelectedCard_Player_i(currentPlayer, j, i - DuelBoard.getColumns() * currentPlayer);
                    idPickedLast = pickCard(j, i);
                    selectedCardOrder++;
                }
            } else{
                currentPlayer = (currentPlayer+1)%2;
            }
        }
        else {
            currentPlayer = (currentPlayer+1)%2;
        }
    }

    /**
     * function that is used whenever CPU plays in "One on One" mode to pick card first.
     */

    private void CPUStarts(){
        isPlayerPicking = false;
        Point selectedCoordinate;
        Timer CPUstall = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (playerKind[currentPlayer] == 0) {
                    isPlayerPicking = true;
                }
                else {
                    CPUResponds(idPickedLast);
                }
            }
        });
        selectedCoordinate = Player[currentPlayer].pickCardDuelInitiative();
        int row = (int) Math.round(selectedCoordinate.getX());
        int column = (int) Math.round(selectedCoordinate.getY());
        DuelBoard.setSelectedCard_Player_i(currentPlayer, row, column - DuelBoard.getColumns()*currentPlayer);
        idPickedLast = pickCard(row , column);
        Player[currentPlayer].memorize(row, column, idPickedLast);
        selectedCardOrder++;
        currentPlayer = (currentPlayer + 1) % 2;
        informationLabel.setText(messages.getString("Turn player is") + " " +
                Player[currentPlayer].getName());
        CPUstall.setRepeats(false);
        CPUstall.start();
    }

    /**
     * This function is used whenever CPU plays in "One on One" mode in response to a pick of the previous player.
     * Therefore, it needs that player's ID.
     * @param id It is the id of the card that is picked previously.
     */

    private void CPUResponds(int id){
        Timer CPUresponds = new Timer(1000*duration, compareCards);
        CPUresponds.setRepeats(false);
        Point[] selectedCoordinate;
        selectedCoordinate = Player[currentPlayer].pickCardDuelRespond(id);
        int row = (int) Math.round(selectedCoordinate[0].getX());
        int column = (int) Math.round(selectedCoordinate[0].getY());
        DuelBoard.setSelectedCard_Player_i(currentPlayer, row, column - 4*currentPlayer);
        idPickedLast = pickCard(row, column);
        Player[currentPlayer].memorize(row, column, idPickedLast);
        selectedCardOrder++;
        CPUresponds.start();
    }

    /**
     * function that flips a card based on the coordinates of row. and column.
     * @param row the row of the card that is selected
     * @param column the column of the card that is selected
     * @return id which indicates the card id that cooresponds to the parameter coordinates
     */

    private int pickCard(int row, int column){
        table[row][column].setOpen(true);
        displayCard(row, column);
        cardPicks[selectedCardOrder][0] = row;
        cardPicks[selectedCardOrder][1] = column;
        int id = table[row][column].getId();
        return id;
    }


    /**
    * function that makes all non-"goldish" CPU do a memorize attempt of the card that it was picked
    */

    private void CPUMemorize(){
        for(int i=0; i<numOfPlayers; i++){
            if(playerKind[i]>1){
                Player[i].memorize(cardPicks[selectedCardOrder][0], cardPicks[selectedCardOrder][1],
                        table[cardPicks[selectedCardOrder][0]][cardPicks[selectedCardOrder][1]].getId());
            }
        }
    }

    private void CPUconsiderRemovedCards(){
        for(int i = 0; i < numOfPlayers; i++) {
            Player[i].considerRemovedCard(idPickedLast);
        }
    }

    /**
     * function that is performs a turn of a CPU player
     */

    private void CPUPlays(){
        Point[] selectedCoordinates;
        timer = new Timer(1000*duration, compareCards);
        selectedCoordinates = Player[currentPlayer].pickCard();
        for(int i = 0; i < selectedCoordinates.length; i++){
            idPickedLast = pickCard((int) Math.round(selectedCoordinates[i].getX()), (int) Math.round(selectedCoordinates[i].getY()));
            selectedCardOrder++;
        }
        timer.setRepeats(false);
        timer.start();
    }
    /**
     * fuction that finds the player(s) with the highest amount of pairs they found.
     */
    private void findWinners(){
        int max = Player[0].getPairs();
        for(int i = 1; i < numOfPlayers; i++){
            if(max < Player[i].getPairs()){
                max = Player[i].getPairs();
            }
        }
        declareWinner(max);
    }

    /**
     * function that changes the label to display the winner or if multiple players found the same amount of pairs
     * (draw). If the player who won is human, he gets a win point, and compares his wins with the player who won
     * the most wins without exiting that mode.
     * @param pairsTheyFound This parameter checks how many players (and who if he's the one
     * with the highest pairs) won the game.
     */
    private void declareWinner(int pairsTheyFound){
        int counter = 0;
        int winner = 0;
        for(int i = 0; i < numOfPlayers; i++){
            if(pairsTheyFound == Player[i].getPairs()){
                counter++;
                winner = i;
            }
        }
        if(counter == 1){
            informationLabel.setText(messages.getString("Winner is") + " " + Player[winner].getName() + "!");
            if(playerKind[winner] == 0) {
                Player[winner].won();
                saveMulti(winner);
            }
        }
        else{
            informationLabel.setText(messages.getString("Draw occured") + "!");
        }
        playAgainButton.setVisible(true);
        playAgainButton.setEnabled(true);
    }

    /**
     * function that creates the basic elements of the game board. Then, it creates the appropriate game according to
     * what type of game the player chose with gameType as parameter. If gameType is 1, then it creates the
     * "Singleplayer" game. If gameType is 2, then it creates the "Custom Mode game". If gameType is 3, then it
     * creates the "One on One" game. Finally, it adds the board to the "game" frame and it opens, while the menu
     * window closes
     * @param gameType
     */

    private void createGameType(final int gameType){
        exitedGame = true;
        currentPlayer = 0;
        game = new JFrame(messages.getString("Memory Game"));
        game.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        gamePanel = new JPanel(new BorderLayout());
        informationLabel = new JLabel("3101-3137", SwingConstants.CENTER);
        cardPanel = new JPanel(new GridLayout(rows, columns, 10, 10));
        card = new JLabel[rows][columns];
        playerInfo = new JLabel[numOfPlayers][2];
        exitButton = new JButton(messages.getString("Exit"));
        playAgainButton = new JButton((messages.getString("Play Again")));
        playAgainButton.setVisible(false);
        playAgainButton.setEnabled(false);
        for(int i = 0; i < numOfPlayers; i++){
            playerInfo[i][0] = new JLabel("" + Player[i].getName(), SwingConstants.CENTER);
            playerInfo[i][1] = new JLabel("0", SwingConstants.CENTER);
        }
        createEastArea();
        createWestArea();
        for(int i = 0; i < rows;i++){
            for(int j = 0; j < columns ; j++ ){
                card[i][j] = new JLabel();
            }
        }
        if (gameType == 1){
            createSingleplayerGame();
        }
        else if (gameType == 2){
            createCustomModeGame();
        }
        else if(gameType == 3){
             createOneOnOneGame();
        }

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exitedGame = true;
                openMainMenu();
                game.setVisible(false);
                window.setVisible(true);

            }
        });

        playAgainButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.setVisible(false);
                createGameBoard();
                clearParticipantsData();
                createGameType(gameType);
            }
        });

        game.add(gamePanel);
        game.pack();
        window.setVisible(false);
        game.setVisible(true);
        game.setResizable(false);
        displayAllCards();
    }

    /**
     * function that creates specific elements, variables and Listeners based on "SinglePlayer" mode only.
     */

    private void createSingleplayerGame(){
        cardPicks = new int[Board.getSameCopies()][2];
        table = Board.getTable();
        for(int i = 0; i< rows; i++) {
            for (int j = 0; j < columns; j++) {
                displayCard(i, j);
                cardPanel.add(card[i][j]);
            }
        }
        cardPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if(isPlayerPicking) {
                    int x = e.getX();
                    int y = e.getY();
                    findCard(x, y);
                    if(selectedCardOrder==cardsOfSameCopy){
                        isPlayerPicking = false;
                        timer = new Timer(duration*1000, compareCards);
                        timer.setRepeats(false);
                        timer.start();
                    }
                }
            }
        });

        compareCards = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Player[0].madeMove();
                if(Board.guessResult(cardPicks)){
                    Player[0].completedPair();
                }
                for(int i=0; i < cardsOfSameCopy; i++){
                    displayCard(cardPicks[i][0],cardPicks[i][1]);
                }
                updateSinglePlayerGame();
            }
        };
    }

    /**
     * fuction that updates the elements based on player's actions in the "Singleplayer" game, based on the logic
     * of the memory game.
     */

    private void updateSinglePlayerGame(){
        if(!exitedGame) {
            if (!Board.gameOver()) {
                selectedCardOrder = 0;
                informationLabel.setText(messages.getString("Turn") + " " + (Player[0].getMoves() + 1));
                playerInfo[0][1].setText("" + Player[0].getPairs());
                isPlayerPicking = true;
            } else {
                informationLabel.setText(messages.getString("You won in") + " " + Player[0].getMoves() + " " +
                        messages.getString("turns") + "!");
                saveSingle();
                playAgainButton.setVisible(true);
                playAgainButton.setEnabled(true);
                isPlayerPicking = false;
            }
        }
    }

    /**
     * function that creates specific elements, variables and Listeners based on "Custom mode game" only.
     */

    private void createCustomModeGame(){
        cardPicks = new int[Board.getSameCopies()][2];
        table = Board.getTable();
        for(int i = 0; i< rows; i++) {
            for (int j = 0; j < columns; j++) {
                displayCard(i, j);
                cardPanel.add(card[i][j]);
            }
        }
        cardPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if(isPlayerPicking) {
                    int x = e.getX();
                    int y = e.getY();
                    findCard(x, y);
                    if(selectedCardOrder==cardsOfSameCopy){
                        isPlayerPicking = false;
                        timer = new Timer(duration*1000, compareCards);
                        timer.setRepeats(false);
                        timer.start();
                    }
                }
            }
        });

        compareCards = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(Board.guessResult(cardPicks)){
                    CPUconsiderRemovedCards();
                    Player[currentPlayer].completedPair();
                    playerInfo[currentPlayer][1].setText("" + Player[currentPlayer].getPairs());
                }
                else{
                    currentPlayer = (currentPlayer+1)%numOfPlayers;
                }
                for(int i=0; i < cardsOfSameCopy; i++){
                    displayCard(cardPicks[i][0],cardPicks[i][1]);
                }
                updateCustomModeGame();
            }
        };
    }

    /**
     * fuction that updates the elements based on player's actions in the "Custom mode" game, based on the logic
     * of the memory game.
     */

    private void updateCustomModeGame(){
        if(!exitedGame) {
            if (!Board.gameOver()) {
                selectedCardOrder = 0;
                informationLabel.setText(messages.getString("Turn player is") + " " +
                        Player[currentPlayer].getName());
                if (playerKind[currentPlayer] == 0) {
                    isPlayerPicking = true;
                } else {
                    CPUPlays();
                }
            } else {
                findWinners();
                isPlayerPicking = false;
            }
        }

    }

    /**
     * function that creates specific elements, variables and Listeners based on "One on One"  game only.
     */

    private void createOneOnOneGame(){
        cardPicks = new int[2][2];
        table = DuelBoard.getTable();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                displayCard(i, j);
                cardPanel.add(card[i][j]);
            }
        }
        cardPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (isPlayerPicking) {
                    int x = e.getX();
                    int y = e.getY();
                    findCard(x, y);
                    if (selectedCardOrder == cardsOfSameCopy) {
                        isPlayerPicking = false;
                        timer = new Timer(duration * 1000, compareCards);
                        timer.setRepeats(false);
                        timer.start();
                    }
                    else{
                        currentPlayer = (currentPlayer + 1) % 2;
                        informationLabel.setText(messages.getString("Turn player is") + " " +
                                Player[currentPlayer].getName());
                        if (playerKind[currentPlayer] == 0) {
                            isPlayerPicking = true;
                        } else {
                            CPUResponds(idPickedLast);
                        }
                    }
                }
            }
        });

        compareCards = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(DuelBoard.OutcomeOfSelections()){
                    CPUconsiderRemovedCards();
                    table[cardPicks[0][0]][cardPicks[0][1]] = null; // function outcomeOfSelections has a bug: unable to remove the cards with the same id (bug), therefore it has to be done here
                    table[cardPicks[1][0]][cardPicks[1][1]] = null; // function outcomeOfSelections has a bug: unable to remove the cards with the same id (bug), therefore it has to be done here
                    Player[currentPlayer].completedPair();
                    playerInfo[currentPlayer][1].setText("" + Player[currentPlayer].getPairs());
                }
                for(int i=0; i < cardsOfSameCopy; i++) {
                    displayCard(cardPicks[i][0], cardPicks[i][1]);
                }
                updateOneOnOneGame();
            }
        };
    }

    /**
     * fuction that updates the elements based on player's actions in the "Singleplayer" game, based on the logic
     * of the memory game.
     */

    private void updateOneOnOneGame(){
        if(!exitedGame) {
            selectedCardOrder = 0;
            if (!DuelBoard.gameOver()) {
                informationLabel.setText(messages.getString("Turn player is") + " " +
                        Player[currentPlayer].getName());
                if (playerKind[currentPlayer] == 0) {
                    isPlayerPicking = true;
                } else {
                    CPUStarts();
                }
            } else {
                findWinners();
                isPlayerPicking = false;
            }
        }

    }

    /**
     * fucntion that creates the west area of the memory game, the card panel and the information label
     */

    private void createWestArea(){
        final JPanel westArea = new JPanel(new BorderLayout());
        final JPanel informationPanel = new JPanel(new BorderLayout());
        informationPanel.add(informationLabel, BorderLayout.CENTER);
        informationPanel.setPreferredSize(new Dimension(200, 30));
        westArea.add(informationPanel, BorderLayout.SOUTH);
        westArea.add(cardPanel, BorderLayout.CENTER);
        gamePanel.add(westArea, BorderLayout.CENTER);
    }

    /**
     * function that creates the north east area of memory game. It has a 2 dimension
     * array of labels of the player's name and his turn, and the exit button
     */

    private void createEastArea() {
        final JPanel eastArea = new JPanel(new BorderLayout());
        final JPanel playerData = new JPanel(new GridLayout(numOfPlayers + 1, 2));
        final JPanel buttonArea = new JPanel(new GridLayout(2, 1 , 10, 0));
        buttonArea.add(playAgainButton);
        buttonArea.add(exitButton);
        final JLabel playerLabel = new JLabel(messages.getString("Player"), SwingConstants.CENTER);
        final JLabel turnLabel = new JLabel(messages.getString("Score"), SwingConstants.CENTER);
        playerData.add(playerLabel);
        playerData.add(turnLabel);
        for (int i = 0; i < numOfPlayers; i++) {
            playerData.add(playerInfo[i][0]);
            playerData.add(playerInfo[i][1]);
        }
        eastArea.add(buttonArea, BorderLayout.SOUTH);
        eastArea.add(playerData, BorderLayout.CENTER);
        eastArea.setPreferredSize(new Dimension(150, 0));
        gamePanel.add(eastArea, BorderLayout.EAST);
    }

    /**
     * function that saves the moves of a "human" player with a name by using the classes Name_and_Score and
     * Highscore_file_Manager. This function is called for any "Singleplayer" mode game.
     */

    private void saveSingle() {
        Name_and_Score save = new Name_and_Score(Player[0].getName(), Player[0].getMoves());
        Highscore_File_Manager file = new Highscore_File_Manager();
        if (boardType == 1) {
            file.Add4x6Single(save);
        } else if (boardType == 2) {
            file.Add6x8Single(save);
        } else {
            file.Add6x6Single(save);
        }
    }

    /**
     * function that saves the moves of a "human" player with a name by using the classes Name_and_Score and
     * Highscore_file_Manager. This function is called for any "Custom mode" game, or "One on One" game.
     */

    private void saveMulti(int playerWhoWon){
        Name_and_Score save = new Name_and_Score(Player[0].getName(), Player[0].getWins());
        Highscore_File_Manager file = new Highscore_File_Manager();
        if(gameType == 4){
            file.AddDuel(save);
        }
        else if (boardType == 1) {
            file.Add4x6Multi(save);
        } else if (boardType == 2) {
            file.Add6x8Multi(save);
        } else {
            file.Add6x6Multi(save);
        }
    }

    private void clearParticipantsData() {
        for (int i = 0; i < numOfPlayers; i++) {
            if (playerKind[i] == 0) {
                Player[i].resetMoves();
                Player[i].resetPairs();
            } else if (boardType == 4) {
                Player[i] = new CPU(name[i], playerKind[i], DuelBoard, i);
            } else {
                Player[i] = new CPU(name[i], playerKind[i], Board);
            }
        }
    }
}

