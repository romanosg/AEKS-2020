/**
 * @author Konstantinos Stavratis
 * @author Georgios Romanos
 * @version 1.1
 * Class in the UserInterface. It uses other classes to create the Memory game and it has functions that include
 * communication with the user in both inputs and outputs.
 */
package UserInterface;

import BackEnd.Board;
import BackEnd.Human_Player;
import BackEnd.Player;

import java.util.Scanner;

public class UserInterface {
    Scanner input;

    /**
     * Constructor of Class UserInterface
     */
    public UserInterface()
    {
        input = new Scanner(System.in);
    }

    public void firstDisplay(Board gameBoard)
    {
        gameBoard.openAllCards();
        System.out.print("   ");
        for (int i = 0; i < gameBoard.getColumns(); i++) {
            System.out.print("Υ" + i + " ");
        }

        for (int i = 0; i < gameBoard.getRows(); i++) {
            System.out.println();
            System.out.print("X" + i + " ");
            for (int k = 0; k < gameBoard.getColumns(); k++)
            {
                if (gameBoard.getTable()[i][k].getId() < 10)
                    System.out.print("0");
                System.out.print(gameBoard.getTable()[i][k].getId() + " ");

            }
        }
        System.out.println();

        gameBoard.closeAllCards();

        /**
         * This part of the source code delays the program from doing further action for 3 seconds (3000 milliseconds)
         * https://www.tutorialspoint.com/java/lang/system_currenttimemillis.htm
         * after the delay, program scrolls down 30 times and proceeds to the next turn.
         */
        int timerStart;
        int timerFinish;
        System.out.println("Please wait a bit...");
        timerStart = (int) System.currentTimeMillis();
        timerFinish = timerStart;

        while((timerFinish - timerStart) < 6000){
            timerFinish = (int) System.currentTimeMillis();
        }

        for(int i=0; i<30; i++){
            System.out.println();
        }
    }

    /**
     * Function that prints to user the Board of all face-up cards, face-down cards and removed from game cards.
     * @param gameBoard
     */
    public void displayBoard(Board gameBoard) {
        System.out.print("   ");
        for (int i = 0; i < gameBoard.getColumns(); i++) {
            System.out.print("Υ" + i + " ");
        }
        for (int i = 0; i < gameBoard.getRows(); i++) {
            System.out.println();
            System.out.print("X" + i + " ");
            for (int k = 0; k < gameBoard.getColumns(); k++) {
                if (gameBoard.getTable()[i][k] == null) {
                    System.out.print("   ");
                } else {
                    if (gameBoard.getTable()[i][k].isOpen()) {
                        if (gameBoard.getTable()[i][k].getId() < 10)
                            System.out.print("0");
                        System.out.print(gameBoard.getTable()[i][k].getId() + " ");
                    } else {
                        System.out.print("-- ");
                    }
                }
            }
        }
        System.out.println();


    }

    /**
     * function that contains all the logic behind memory game. In here, the user gives his inputs regarding the game
     * mode, and every card's coordinates with validity check(s). As an output, he gets pre-game instructions regarding
     * game mode, the updated displayed board from function displayBoard(board) whenever required, error messages
     * regarding wrong inputs and any required messaged behind the logic of the memory game. After the game ends,
     * user gets the output of the turns required to find all the pairs of cards. More info about the function within its
     * source code:
     */
    public void start()
    {
        /**
         * class objects;
         */
        Board gameBoard;
        Player[] player = new Player[1];
        player[0] = new Human_Player();

        /**
         * usuable variables
         */
        int gameMode;
        int timerStart;
        int timerFinish;
        boolean flag;

        /**
         * Starting game mode instructions displayed to user
         */
        System.out.println("Welcome to Memory Game. A list of gamemodes is listed below:");
        System.out.println("Game mode 1: 4 rows, 6 columns , 2 same copies of cards.");
        System.out.println("Game mode 2: 6 rows, 8 columns , 2 same copies of cards.");
        System.out.println("Game mode 3: 6 rows, 6 columns , 3 same copies of cards.");

        /**
         * request of a game mode type from user with validity check.
         */
        do {
            System.out.print("Please select a game mode: ");
            gameMode = input.nextInt();
            if (gameMode < 1 || gameMode > 3)
                System.out.println("Game mode doesn't exist! Try again!");
        } while (gameMode < 1 || gameMode > 3);

        /**
         * construction of the game board regarding the game mode value
         */
        if (gameMode == 1) {
            gameBoard = new Board(4, 6, 2);
        } else if (gameMode == 2) {
            gameBoard = new Board(6, 8, 2);
        } else {
            gameBoard = new Board(6, 6, 3);
        }

        /**
         * the following 2 dimension array (temporarilly) saves the coordinate(s) of a desired card. The first dimension
         * represents the number of card the player chooses during a turn. The second dimension represents the coordinate
         * X (for 0) or the coordinate Y (for 1) the player chooses.
         */
        int[][] guesses = new int[gameBoard.getSameCopies()][2];

        firstDisplay(gameBoard);


        while(!gameBoard.gameOver())
        {
            displayBoard(gameBoard);

            for (int i=0; i<guesses.length;i++)
            {
                System.out.println("Turn #" + (player[0].getMoves() + 1) + ": Pick your card #" + (i+1));
                do {
                    flag = true;

                    /**
                     * Inputting x coordinate.
                     */

                    System.out.print("X coordinate of card: ");
                    guesses[i][0] = input.nextInt();

                    /**
                     * Inputting y coordinate.
                     */

                    System.out.print("Y coordinate of card: ");
                    guesses[i][1] = input.nextInt();

                     /**
                      *  Validity test that checks if chosen card's coordinates are out of bounds
                      */

                    if((guesses[i][0] < 0) || (guesses[i][0] >= gameBoard.getRows())){
                        flag = false;
                        System.out.println("Selected coordinate X is out of bounds!");
                    }
                    if((guesses[i][1]< 0) || (guesses[i][1] >= gameBoard.getColumns())){
                        flag = false;
                        System.out.println("Selected coordinate Y is out of bounds!");
                    }

                    /**
                     * Validity test that checks if chosen card is removed from the game
                     */

                    if(flag) {
                        if ((gameBoard.getTable()[guesses[i][0]][guesses[i][1]] == null)) {
                            System.out.println("Chosen card with those coordinates is removed from game");
                            flag = false;
                        }
                    }

                    /**
                     * Validity test that checks if the chosen card is face-up
                     */

                    if(flag) {
                        if (gameBoard.getTable()[guesses[i][0]][guesses[i][1]].isOpen()) {
                            System.out.println("Chosen card with those coordinates is face-up!");
                            flag = false;
                        }
                    }

                }while(!flag);

                /**
                 * memory game's logic: Flips face-up the card coordinates the player chose and the board gets updated.
                 */

                gameBoard.getTable()[guesses[i][0]][guesses[i][1]].setOpen(true);

                displayBoard(gameBoard);
            }

            /**
             * memory game's logic: Checks if all the cards are from the same copy.
             */

            if(gameBoard.guessResult(guesses))
            {
                player[0].completedPair();
                System.out.println("All cards of the same copy found!");
            }
            else{
                System.out.println("All cards of the same copy were not found.");
            }
            player[0].madeMove();

            /**
             * This part of the source code delays the program from doing further action for 3 seconds (3000 milliseconds)
             * https://www.tutorialspoint.com/java/lang/system_currenttimemillis.htm
             * after the delay, program scrolls down 30 times and proceeds to the next turn.
             */
            System.out.println("Please wait a bit...");
            timerStart = (int) System.currentTimeMillis();
            timerFinish = timerStart;

            while((timerFinish - timerStart) < 3000){
                timerFinish = (int) System.currentTimeMillis();
            }

            for(int i=0; i<30; i++){
                System.out.println();
            }

        }

        /**
         * the part in which game ends and shows in how many turns the player used to find all copies of all cards.
         */
        displayBoard(gameBoard);
        System.out.println();
        System.out.print("Congratulations! You won in " + player[0].getMoves() + " moves!");
    }
}
