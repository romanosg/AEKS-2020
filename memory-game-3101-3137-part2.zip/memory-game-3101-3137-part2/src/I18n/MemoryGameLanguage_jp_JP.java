/**
 * the following class is a list of messages that are being translated to japanese.
 * @author Konstantinos Stavratis
 * @version 1.0
 */
package I18n;

import UserInterface.MemoryGameApp;

import java.util.ListResourceBundle;

public class MemoryGameLanguage_jp_JP extends ListResourceBundle {

    public Object[][] getContents() {
        return contents;
    }

    private final Object[][] contents = {
            {"Memory Game", "記憶ゲーム"},
            {"Welcome to memory game!", "記憶ゲームへようこそ!"},
            {"Play", "ゲーム"},
            {"Settings", "設定"},
            {"Highscores", "最高スコア"},
            {"Please select one of the following gamemodes:", "次のゲームモードから一つ選んで下さい："},
            {"Table:", "表類:"},
            {"Players", "プレイヤー"},
            {"Player", "プレイヤー"},
            {"4x6 - pairs of two cards", "4x6 - 二枚 "},
            {"6x8 - pairs of two cards", "6x8 -  二枚"},
            {"6x6 - pairs of three cards", "6x6 - 三枚 "},
            {"Singleplayer", "一人"},
            {"One on One", "一人対一人"},
            {"Custom Mode", "カスタム"},
            {"Extras", "エクストラ"},
            {"Return to main menu", "最初メニューに戻りますか。"},
            {"What do you wish to change?", "何を変えたいですか。"},
            {"Change language:", "言語変"},
            {"Face-up card duration:", "カードの開い時間"},
            {"Card color:", "カードの色"},
            {"Red", "赤"},
            {"Blue", "青"},
            {"Name (up to 9 letters)", "名前"},
            {"Back", "戻り"},
            {"Next", "次"},
            {"Start", "初め"},
            {"Human", "人間"},
            {"Goldfish", "金魚"},
            {"Kangaroo", "カンガルー"},
            {"Elephant", "象"},
            {"Exit", "戻り"},
            {"Turn", "回"},
            {"turns", "回"},
            {"Score", "スコア"},
            {"You won in", "に買った"},
            {"Winner is", "勝者は"},
            {"Turn player is", "の番です。"},
            {"Draw occured", "引き分け"},
            {"Play Again", "再開"},

    };
}

