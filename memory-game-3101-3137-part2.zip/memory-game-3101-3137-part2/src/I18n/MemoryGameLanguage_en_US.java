/**
 * the following class is a list of messages that are being translated to english
 * @author Georgios Romanos
 * @version 1.0
 */

package I18n;

import UserInterface.MemoryGameApp;

import java.util.ListResourceBundle;

public class MemoryGameLanguage_en_US extends ListResourceBundle {

    public Object[][] getContents() {
        return contents;
    }

    private final Object[][] contents = {
            {"Memory Game", "Memory Game"},
            {"Welcome to memory game!", "Welcome to memory game!"},
            {"Play", "Play"},
            {"Settings", "Settings"},
            {"Highscores", "Highscores"},
            {"Please select one of the following gamemodes:", "Please select one of the following gamemodes:"},
            {"Table:", "Table:"},
            {"Players", "Players"},
            {"Player", "Player"},
            {"4x6 - pairs of two cards", "4x6 - pairs of two cards"},
            {"6x8 - pairs of two cards", "6x8 - pairs of two cards"},
            {"6x6 - pairs of three cards", "6x6 - pairs of three cards"},
            {"Singleplayer", "Singleplayer"},
            {"One on One", "One on One"},
            {"Custom Mode", "Custom Mode"},
            {"Extras", "Extras"},
            {"Return to main menu", "Return to main menu"},
            {"What do you wish to change?", "What do you wish to change?"},
            {"Change language:", "Change language:"},
            {"Face-up card duration:", "Face-up card duration:"},
            {"Card color:", "Card color:"},
            {"Red", "Red"},
            {"Blue", "Blue"},
            {"Name (up to 9 letters)", "Name (up to 9 letters)"},
            {"Back", "Back"},
            {"Next", "Next"},
            {"Start", "Start"},
            {"Human", "Human"},
            {"Goldfish", "Goldfish"},
            {"Kangaroo", "Kangaroo"},
            {"Elephant", "Elephant"},
            {"Exit", "Exit"},
            {"Turn", "Turn"},
            {"turns", "turns"},
            {"Score", "Score"},
            {"You won in", "You won in"},
            {"Winner is", "Winner is"},
            {"Turn player is", "Turn player is"},
            {"Draw occured", "Draw occured"},
            {"Play Again", "Play Again"},
    };
}