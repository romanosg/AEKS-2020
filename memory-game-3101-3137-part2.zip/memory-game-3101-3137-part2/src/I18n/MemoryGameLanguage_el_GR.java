/**
 * the following class is a list of messages that are being translated to greek
 * @author Georgios Romanos
 * @version 1.0
 */

package I18n;

import UserInterface.MemoryGameApp;

import java.util.ListResourceBundle;

public class MemoryGameLanguage_el_GR extends ListResourceBundle {

    public Object[][] getContents() {
        return contents;
    }

    private final Object[][] contents = {
            {"Memory Game", "Παιχνίδι Μνήμης"},
            {"Welcome to memory game!", "Καλοσωρίσατε στο παιχνίδι μνήμης!"},
            {"Play", "Έναρξη"},
            {"Settings", "Ρυθμίσεις"},
            {"Highscores", "Καλύτερα σκορ"},
            {"Please select one of the following gamemodes:", "Παρακαλώ επιλέξτε ένα από τα παρακάτω είδη παιχνιδιού:"},
            {"Table:", "Ταμπλό:"},
            {"Players", "Παίκτες"},
            {"Player", "Παίκτης"},
            {"4x6 - pairs of two cards", "4x6 - δυάδες ίδιων καρτών "},
            {"6x8 - pairs of two cards", "6x8 - δυάδες ίδιων καρτών "},
            {"6x6 - pairs of three cards", "6x6 - τριάδες ίδιων καρτών "},
            {"Singleplayer", "Ένας Παίκτης"},
            {"One on One", "Ένας Εναντίων Ενός"},
            {"Custom Mode", "Προσαρμοσμένο"},
            {"Extras", "Έξτρα"},
            {"Return to main menu", "Επιστροφή στο κυρίως μενού"},
            {"What do you wish to change?", "Τι επιθυμείτε να αλλάξετε;"},
            {"Change language:", "Αλλάξτε γλώσσα:"},
            {"Face-up card duration:", "Διάρκεια ανοίγματος καρτών:"},
            {"Card color:", "Χρώμα κάρτας"},
            {"Red", "Κόκκινο"},
            {"Blue", "Μπλε"},
            {"Name (up to 9 letters)", "Όνομα (εώς 9 γράμματα)"},
            {"Back", "Πίσω"},
            {"Next", "Επόμενο"},
            {"Start", "Ξεκίνα"},
            {"Human", "Χρήστης"},
            {"Goldfish", "Χρυσόψαρο"},
            {"Kangaroo", "Κανγκουρό"},
            {"Elephant", "Ελέφαντας"},
            {"Exit", "Έξοδος"},
            {"Turn", "Γύρος"},
            {"turns", "γύρους"},
            {"Score", "Πόντοι"},
            {"You won in", "κέρδισες σε"},
            {"Winner is", "Νίκησε ο/η"},
            {"Turn player is", "Είναι ο γύρος του/της"},
            {"Draw occured", "Προέκυψε ισοπαλία"},
            {"Play Again", "Ξαναπαίξτε"},

    };
}