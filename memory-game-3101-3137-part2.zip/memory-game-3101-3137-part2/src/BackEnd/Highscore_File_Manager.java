/**
 * @author Konstantinos Stavratis
 * @version 1.1
 * This class is used to manage the highscore file.
 */
package BackEnd;


import java.io.*;

public class Highscore_File_Manager {

    /**
     * Indicates what is the maximum capacity of file "Highscores.bin"
     * Default value given by exercise is 7, one for each game mode.
     */
    private final static int highscore_spots = 7;
    private final static int single_player_spots = 3;
    private static Integer Infinite = Integer.MAX_VALUE;
    private static int infinite = Infinite;


    /**
     * Updates the file "Highscore.bin".
     * @param scores All names and scores that will be written down on the "Highscore.bin" file.
     */
    private void ScoresWrite(Name_and_Score[] scores) {
        int writeIndex;
        if (scores.length < highscore_spots) {
            writeIndex = scores.length;
        } else
            writeIndex = highscore_spots;


        //Sort_Highscores(scores);
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream("Highscores.bin")))) {
            out.writeInt(writeIndex);
            for (int i = 0; i < writeIndex; i++) {
                out.writeUTF(scores[i].getName());
                out.writeInt(scores[i].getScore());
            }
        } catch (IOException e) {
            System.out.println("Παρουσιάστηκε σφάλμα.");
        }
    }

    /**
     * Reads the data from the "Highscores.bin" file.
     * @return Array of all Name_and_Score objects.
     */
    public Name_and_Score[] Read_Highscores() {


        Name_and_Score[] currentHighscores;

        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream("Highscores.bin")))) {

            int length = in.readInt();
            currentHighscores = new Name_and_Score[length];
            for (int i = 0; i < currentHighscores.length; i++) {

                String name = in.readUTF();
                int score = in.readInt();

                currentHighscores[i] = new Name_and_Score(name, score);


            }

            return currentHighscores;
        }
        catch (FileNotFoundException e3) {
            CreateEmptyFile();
            return Read_Highscores();
        }
        catch (IOException e2) {
            System.err.println(e2.getClass());
            CreateEmptyFile();
            return Read_Highscores();
        }

    }

    /**
     * Returns a specific Name_and_score item form the "Highscores.bin" file.
     * @param position represents which item it wants to read.
     * @return Name_and_score object (regardless of if scores is turns or wins) we want to read.
     */
    private Name_and_Score Read_Single_Highscore(int position)
    {
        Name_and_Score currentHighscore;

        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream("Highscores.bin")))) {
            /*
            Skipping the first integer, which represents how many Name_and_value objects
            the "Highscore.bin" file contains.
             */
            in.readInt();
            for (int i=0;i<position;i++)
            {
                in.readUTF();
                in.readInt();
            }
            String currentRecordName = in.readUTF();
            int currentRecordScore = in.readInt();
            currentHighscore = new Name_and_Score(currentRecordName,currentRecordScore);
            return currentHighscore;
    }
        catch (FileNotFoundException e4)
        {
            CreateEmptyFile();
            return Read_Single_Highscore(position);
        }
        catch (IOException e5) {
            System.err.println(e5.getClass());
            return null;
        }


    }

    public Name_and_Score ReadSingle4x6() {return Read_Single_Highscore(0);}

    public Name_and_Score ReadSingle6x8() {return Read_Single_Highscore(1);}

    public Name_and_Score ReadSingle6x6() {return Read_Single_Highscore(2);}

    public Name_and_Score ReadMulti4x6() {return Read_Single_Highscore(3);}

    public Name_and_Score ReadMulti6x8() {return Read_Single_Highscore(4);}

    public Name_and_Score ReadMulti6x6() {return Read_Single_Highscore(5);}

    public Name_and_Score ReadDuel() {return Read_Single_Highscore(6);}



    /**
     * Is used to add a new record in the Multiplayer modes.
     * @param NewRecord the most recent score, according to which the "Highscore.bin" file will be updated.
     * @param position is used as an index for the position the specific record has on the "Highscore.bin" file.
     */
    private void AddNewMultiScore(Name_and_Score NewRecord, int position) {
        Name_and_Score[] previousHighScores = Read_Highscores();
        Name_and_Score oldSingleHighScore = Read_Single_Highscore(position);
        Name_and_Score[] newHigscores = new Name_and_Score[previousHighScores.length];

        for (int i = 0; i < position; i++) {
            newHigscores[i] = new Name_and_Score(previousHighScores[i].getName(), previousHighScores[i].getScore());
        }
        if (NewRecord.getScore() > oldSingleHighScore.getScore()) {
            newHigscores[position] = new Name_and_Score(NewRecord.getName(), NewRecord.getScore());
        } else {
            newHigscores[position] = new Name_and_Score(oldSingleHighScore.getName(), oldSingleHighScore.getScore());
        }

        for (int i = position + 1; i < previousHighScores.length; i++)
        {
            newHigscores[i] = new Name_and_Score(previousHighScores[i].getName(), previousHighScores[i].getScore());
        }

        ScoresWrite(newHigscores);

    }


    /**
     * Is used to add a new record in the Single Player modes.
     * @param NewRecord the most recent score, according to which the "Highscore.bin" file will be updated.
     * @param position is used as an index for the position the specific record has on the "Highscore.bin" file.
     */
    private void AddNewSingleScore(Name_and_Score NewRecord, int position) {
        Name_and_Score[] previousHighScores = Read_Highscores();
        Name_and_Score oldSingleHighScore = Read_Single_Highscore(position);
        Name_and_Score[] newHigscores = new Name_and_Score[previousHighScores.length];

        for (int i = 0; i < position; i++) {
            newHigscores[i] = new Name_and_Score(previousHighScores[i].getName(), previousHighScores[i].getScore());
        }
        if (NewRecord.getScore() < oldSingleHighScore.getScore()) {
            newHigscores[position] = new Name_and_Score(NewRecord.getName(), NewRecord.getScore());
        } else {
            newHigscores[position] = new Name_and_Score(oldSingleHighScore.getName(), oldSingleHighScore.getScore());
        }

        for (int i = position + 1; i < previousHighScores.length; i++)
        {
            newHigscores[i] = new Name_and_Score(previousHighScores[i].getName(), previousHighScores[i].getScore());
        }

        ScoresWrite(newHigscores);

    }

    /**
     * Adds or does not add the new score to the "Highscore.bin in the Singles 4x6 position.
     * @param New4x6RecordSingle represents the score that will be added to the file.
     */
    public void Add4x6Single(Name_and_Score New4x6RecordSingle){ AddNewSingleScore(New4x6RecordSingle,0); }

    /**
     * Adds or does not add the new score to the "Highscore.bin in the Singles 6x8 position.
     * @param New6x8RecordSingle represents the score that will be added to the file.
     */
    public void Add6x8Single(Name_and_Score New6x8RecordSingle) { AddNewSingleScore(New6x8RecordSingle,1); }

    /**
     * Adds or does not add the new score to the "Highscore.bin in the Singles 6x6 position.
     * @param New6x6RecordSingle represents the score that will be added to the file.
     */
    public void Add6x6Single(Name_and_Score New6x6RecordSingle) { AddNewSingleScore(New6x6RecordSingle, 2);}

    /**
     * Adds or does not add the new score to the "Highscore.bin in the Multiplayer 4x6 position.
     * @param New4x6RecordMulti represents the score that will be added to the file.
     */
    public void Add4x6Multi(Name_and_Score New4x6RecordMulti) {AddNewMultiScore(New4x6RecordMulti,3);}

    /**
     * Adds or does not add the new score to the "Highscore.bin in the Multiplayer 6x8 position.
     * @param New6x8RecordMulti represents the score that will be added to the file.
     */
    public void Add6x8Multi(Name_and_Score New6x8RecordMulti) {AddNewMultiScore(New6x8RecordMulti,4);}

    /**
     * Adds or does not add the new score to the "Highscore.bin in the Multiplayer 6x6 position.
     * @param New6x6RecordMulti represents the score that will be added to the file.
     */
    public void Add6x6Multi(Name_and_Score New6x6RecordMulti) {AddNewMultiScore(New6x6RecordMulti,5);}

    /**
     * Adds or does not add the new score to the "Highscore.bin in the Duel position.
     * @param NewDuelRecord represents the score that will be added to the file.
     */
    public void AddDuel (Name_and_Score NewDuelRecord) {AddNewMultiScore(NewDuelRecord,6);}




    /**
     * Is used to create an empty "Highscore.bin" file when no such file exists before hand.
     * Can be seen at "Read_Highscores" method at "FileNotFoundException" catch.
     *
     */
    private void CreateEmptyFile() {
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream("Highscores.bin")))) {

            out.writeInt(highscore_spots);

            for(int i=0; i<single_player_spots; i++)
            {
                out.writeUTF("Ν/Α");
                out.writeInt(infinite);
            }

            for(int i=single_player_spots; i<highscore_spots; i++)
            {
                out.writeUTF("Ν/Α");
                out.writeInt(0);
            }
        } catch (IOException e) {
            System.out.println("Empty bin file could not be created.");
        }

    }
}

