package BackEnd;

/**
 * @author Konstantinos Stavratis
 * @version 1.1
 * This class represents each card, the set of which consists the board of the game.
 *
 */

public class Card {

    /**
     * Integer variable, which shows the value of the card.
     */
    private int id;
    public int getId() {return id;}


    /**
     * Boolean variable, which testifies whether the card is open or closed, from the eyes of the player.
     * Its default value is false.
     */

    private boolean open;

    /**
     *
     * @return The boolean value of "open"; whether the card is open or  closed to the player.
     */
    public boolean isOpen() {return open;}

    /**
     * Sets the value of is variable "open". You can either have a card open or closed to the player.
     * @param val Boolean value that will be set to variable "open".
     */
    public void setOpen(boolean val) {open = val;}


    /**
     * Constructor of class "BackEnd.Card". The card's id is set to the value given in brackets, while the "open" variable
     * is set to "false".
     * The id of the card is set to the parameter given by the user. The "open" variable's value is still "false".
     * @param id id that the card will have upon its construction.
     */
    Card(int id){
        this.id = id;
        open = false;
    }


}
