package BackEnd;
/**
 * @author Konstantinos Stavratis
 * @version 1.1
 * This class is the board, which the players will use for the game.
 */

import java.util.Random;

public class Board{
    /**
     * A 2d BackEnd.Card array, which consists the cards of the game.
     */
    private Card[][] table;
    /**
     * Rows integer indicates how many rows the board is going to have.
     */
    private int rows;
    /**
     * "columns" integer indicates how many columns the board is going to have.
     */
    private int columns;
    /**
     * "sameCopies" integer indicates how many cards of the same value there are on the board.
     */
    private int sameCopies;
    /**
     * "numberOfCardsInPlay integer indicates how many cards have not been found at any moment in the game.
     */
    private int numberOfCardsInPlay;

    /**
     * Getter for integer "rows".
     * @return integer "rows".
     */
    public int getRows() {return rows;}

    /**
     * Getter for integer "columns".
     * @return integer "columns".
     */
    public int getColumns() {return columns;}

    /**
     * Getter for integer "sameCopies".
     * @return integer "sameCopies".
     */
    public int getSameCopies() {return sameCopies;}

    /**
     * Getter for the board.
     * @return pointer of 2d BackEnd.Card array table.
     */
    public Card[][] getTable() {return table;}

    /**
     * Getter for integer "numberOfCardsInPlay".
     * @return integer "numberOfCardsInPlay".
     */
    public int getNumberOfCardsInPlay() {return numberOfCardsInPlay;}
    /**
     * The constructor of the board. The user gives three parametres, the rows, the columns of the board, as well as how
     * many copies with the same id exist in the board. Note that the BackEnd.Board will only be created when the product of the
     * rows and columns are perfectly divided by the number of the same copies of a card.
     * @param rows Rows of the table
     * @param columns Columns of the table
     * @param sameCopies Number of cards with the same id that exist on the board.
     */

    public Board(int rows, int columns, int sameCopies)
    {
        if(((rows*columns)%sameCopies)==0)
        {
            this.rows =  rows;
            this.columns = columns;
            this.sameCopies = sameCopies;
            table = new Card[rows][columns];

            int[] inputRandomArray = RandomizeArray(CreateSerialArray());
            int currentRow = 0;
            int currentIntegerPosition = 0;
            while(currentRow<rows)
            {
                for (int i=0; i<columns; i++)
                {
                    table[currentRow][i] = new Card(inputRandomArray[currentIntegerPosition]);
                    currentIntegerPosition++;
                }
                currentRow++;
            }
            numberOfCardsInPlay = columns*rows;

        }
        else
            throw new IllegalArgumentException();
    }


    /**
     * This function creates an 1d array with values starting from 0,1,...,n (n belongs in Natural Numbers)
     * where n = rows*columns/sameCopies.
     * @return Returns the 1d array explained above.
     *
     */
    private int[] CreateSerialArray()
    {
        int[] temporaryArray = new int[rows*columns];
        for(int i=0;i<rows*columns/sameCopies;i++)
        {
            for(int k=0; k<sameCopies; k++)
            {
                temporaryArray[i*sameCopies+k] = i;
            }
        }

        return temporaryArray;
    }

    /**
     * A 1d integer array
     * @param array
     * Shuffles the element of a given array of integers in a random order.
     * @return Returns the shuffled array.
     */
    private int[] RandomizeArray(int[] array){
        Random rgen = new Random();

        for (int i=0; i<array.length; i++) {
            int randomPosition = rgen.nextInt(array.length);
            int temp = array[i];
            array[i] = array[randomPosition];
            array[randomPosition] = temp;
        }

        return array;
    }

    /**
     * A function which checks whether all cards have been found, which is the condition for the game to end.
     * @return Returns "true" if the game is over (numberOfCardsInPlay = 0)
     * and "false" if the game isn't over (numberOfCardsInPlay>0).
     */
    public boolean gameOver()
    {
        return (numberOfCardsInPlay==0);
    }


    public void openAllCards()
    {
        for (int i=0; i<rows;i++)
        {
            for (int k=0; k<columns; k++ )
            {
                table[i][k].setOpen(true);
            }
        }
    }

    public void closeAllCards()
    {
        for(int i=0; i<rows; i++)
            for(int k=0; k<columns; k++)
            {
                table[i][k].setOpen(false);
            }
    }

    /**
     * Calculates whether the cards given have the same id or not.
     * Used to help method "guessResult".
     *
     * @param guesses guesses is a 2d integer where i is the number of picks a player can make
     *      * and guesses[i][0] is the x value of the card picked and
     *      * guesses[i][1] is the y value of the card picked by the player.
     * @return TRUE if all cards have the same id and FALSE if at least one of them has a different Id.
     */

    private boolean haveSameId(int[][] guesses)
    {
        for(int i=0; i<guesses.length;i++)
        {
            for (int k=i+1; k<guesses.length;k++)
            {
                if ((table[guesses[i][0]][guesses[i][1]].getId()!= table[guesses[k][0]][guesses[k][1]].getId()))
                {
                    return false;
                }
            }
        }
        return true;
    }


    /**
     * Calculates whether one of the cards picked have the same coordinates.
     * Used to help method "guessResult".
     *
     * guesses is a 2d integer where i is the number of picks a player can make
     * and guesses[i][0] is the x value of the card picked and
     *  guesses[i][1] is the y value of the card picked by the player.
     * @param guesses is a 2d integer where i is the number of picks a player can make
     * and guesses[i][0] is the x value of the card picked and guesses[i][1] is the
     * y value of the card picked by the player.
     * @return TRUE if one card has the same coordinates with one another.
     * FALSE if all cards have different coordinates.
     */
    private boolean haveSameCoordinates(int[][] guesses)
    {
        for(int i=0; i<guesses.length; i++)
        {
            for(int k=i+1; k<guesses.length;k++)
            {
                if((guesses[i][0]==guesses[k][0]) && (guesses[i][1] == guesses[k][1]))
                {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Checks whether the cards picked make a successful combination, using the two support methods
     * "haveSameId" and "haveSameCoordinates".
     * If it was successful, then it deletes the corresponding
     * "BackEnd.Card" objects of the board, by assigning "null" as its value. Also, it reduces the number of
     * cards currently in play by the number of cards picked.
     * If the combination was unsuccessful, then it resets the cards picked face-down on the board.
     *
     * @param guesses 2d integer array, with the first dimension indicating number of picks
     *                and the second dimension has only 2 values, where value = 0 is the x coordinate given
     *                and value = 1 is the y coordinate given.
     * @return True if combination was successful. False if the combination was unsuccessful.
     */
    public boolean guessResult(int[][] guesses)
    {
        if (haveSameId(guesses) && (!(haveSameCoordinates(guesses))))
        {
            for (int i=0; i<guesses.length; i++)
            {
                table[guesses[i][0]][guesses[i][1]] = null;
            }
            numberOfCardsInPlay-=sameCopies;
            return true;
        }
        else
            for(int i=0; i<guesses.length; i++)
            {
                table[guesses[i][0]][guesses[i][1]].setOpen(false);
            }
        return false;
    }



}