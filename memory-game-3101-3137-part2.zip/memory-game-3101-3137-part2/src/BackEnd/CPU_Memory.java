/**
 * @author Georgios Romanos
 * @author Konstantinos Stavratis
 * @version 1.1
 * This class represents a set of saved coordinates. It is used as the memory data of CPU
 */

package BackEnd;

import java.awt.*;

/**
 * Class that stores a number of card positions for 1 specific ID.
 */
public class CPU_Memory {

    private Point[] coordinates;
    private int length=0;
    private boolean isRemoved = false;

    /**
     * Constructor of CPU_Memory.
     * @param CopiesOfCards 1,2 or 3 depending on the game mode.
     */
    public CPU_Memory(int CopiesOfCards)
    {
        coordinates = new Point[CopiesOfCards];
    }

    /**
     * Saves a new coordinate (if it does not already exist).
     * @param row in which the card exists.
     * @param column in which the card exists.
     */
    public void addPoint(int row, int column) {
        boolean flag = true;
        for (int i = 0; i < length; i++) {
            if ((int) Math.round(coordinates[i].getX()) == row && (int) Math.round(coordinates[i].getY()) == column) {
                flag = false;
            }
        }
        if (flag) {
            coordinates[length++] = new Point(row, column);
        }
    }


    /**
     * Returns a set of coordinates.
     * @return set of coordinates of the id.
     */
    public Point[] getCoordinates() {return coordinates;}

    /**
     * @return  Returns the number of cards of the ID the CPU has memorized.
     */
    public int getLength() { return length; }

    /**
     * Updates CPU that the specific ID has been removed from the game.
     */
    public void removed() {isRemoved = true;}

    /**
     *
     * @return Whether the ID has been removed from the board (or not).
     */
    public boolean getisRemoved () {return isRemoved;}
}
