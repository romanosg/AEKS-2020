package BackEnd;

import java.awt.*;

/**
 * @author Konstantinos Stavratis
 * version 1.2
 * This class emulates a player's stats, those being the moves they've made, their wins and how many pairs/triplets
 * they've had at a certain time in the game, as well as contains their name.
 * Is mother class for classes "Human_Player" and "CPU_Player".
 */
public abstract class Player {

    /**
     * Dictates to player that the ID given is removed completely from the game.
     * @param id of cards removed from the board.
     */
    public abstract void considerRemovedCard(int id);

    /**
     * Stores the data containing the position and id of a card.
     * @param x position of the card.
     * @param y position of the card.
     * @param id of card.
     */
    public abstract void memorize(int x, int y, int id);

    /**
     * Process which decides which set of cards will be picked in normal mode.
     * @return set of picked cards.
     */
    public abstract Point[] pickCard();

    /**
     * Process which decides which set of cards will be picked in duel mode, when playing first in the turn.
     * @return random card.
     */
    public abstract Point pickCardDuelInitiative();

    /**
     * Process which decides which set of cards will be picked in duel mode, when playing second in the turn.
     * @param opponentID id of the card that the opponent picked.
     * @return card that best "answers" the card that the opponent picked.
     */
    public abstract Point[] pickCardDuelRespond(int opponentID);

    /**
     * Tracks the moves that the player has done at a certain point of time in game.
     */
    private int moves;
    /**
     * Tracks how many pairs the player has made up until a certain point in the game.
     */
    private int pairs;
    /**
     * Tracks how many wins the player currently has.
     */
    private int wins;

    /**
     * The name of the player. Initiates (and finalizes at " " if not specified).
     */
    private final String name;

    /**
     * Constructor of class "Person", where all values are set to zero.
     */
    public Player()
    {
        moves = 0;
        pairs = 0;
        wins = 0;
        name = " ";
    }

    /**
     * Constructor of class "Person" when a name is given.
     * @param name refers to the name of this player, which after creation becomes immutable.
     */
    public Player(String name)
    {
        moves = 0;
        pairs = 0;
        wins = 0;
        /*
         * Limits the length of the name given to 8 characters.
         */
        if (name.length()>8)
        {
            this.name = name.substring(0,8);
        }
        else
            this.name = name;
    }


    /**
     * Getter of integer "moves".
     * @return integer "moves".
     */
    public int getMoves() {return moves;}

    /**
     * Increases the moves the player has made up until this point by one.
     */

    public void madeMove() {moves++;}

    /**
     * Getter of integer "pairs".
     * @return integer "pairs".
     */
    public int getPairs() {return pairs;}

    /**
     * Increases the pairs the player has made up till this point by one,
     * whenever he picks a successful combination of cards.
     */

    public void completedPair() {pairs++;}

    /**
     * Returns how many times the player has won.
     * @return integer "wins".
     */
    public int getWins() {return wins;}

    /**
     * Increases the wins of the player by one.
     */
    public void won() {wins++;}

    /**
     * Returns the name of the player.
     * @return Name of player.
     */
    public String getName() {return name;}

    /**
     * makes moves made by the player into 0. It helps on resetting the player information upon rematch.
     */

    public void resetMoves() {moves = 0;}

    /**
     * makes moves made by the player into 0. It helps on resetting the player information upon rematch.
     */

    public void resetPairs() {pairs = 0;}

}


