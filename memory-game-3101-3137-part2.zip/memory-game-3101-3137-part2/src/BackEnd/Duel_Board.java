/**
 * this class is the Duel Board, a specific board that shares 2 different boards with 1 copy of each card to
 * each player.
 * @author Konstantinos Stavratis
 * @author Romanos Georgios
 * @version 1.1
 */
package BackEnd;

import java.util.Random;

public class Duel_Board {
    /**
     * all the variables regarding the duel board
     */

    private Card[][][]tables;
    private int rows=6;
    private int columns=4;
    private int numberOfPairsInPlay;
    private int[][] SelectedCard_Player_i;

    /**
     * function that returns the whole duel board, separating it in both sides
     * @return the tables as separated in sides.
     */

    public Card[][][] getTables() {return tables;}

    /**
     * function that returns the whole duel board
     * @return the overall table
     */

    public Card[][] getTable(){
        Card[][] table = new Card[rows][2*columns];
        for(int k = 0; k < 2; k++) {
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < columns; j++) {
                    table[i][j + columns*k] = tables[k][i][j];
                }
            }
        }
        return table;
    }

    /**
     * function that opens all the cards in duel board
     */

    public void openAllCards()
    {
        for(int k = 0; k < 2; k++) {
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < columns; j++) {
                     tables[k][i][j].setOpen(true);
                }
            }
        }
    }

    /**
     * function that closes all cards in duel board
     */

    public void closeAllCards(){
        for(int k = 0; k < 2; k++) {
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < columns; j++) {
                    tables[k][i][j].setOpen(false);
                }
            }
        }
    }

    /**
     * function that checks if a column in the whole board belongs in the boundaries of a side of the appropriate board
     * @param playerWhoIsPickingCard the turn player who is picking a card. 0 stands for left and 1 stands for right.
     * @param column the column the player chose that card.
     * @return true if the player can pick that card. Otherwise, it returns false.
     */
    public boolean checkBoundaries(int playerWhoIsPickingCard, int column){
        if(playerWhoIsPickingCard==0){
            if(column >= columns) {
                return false;
            }
        }
        if(playerWhoIsPickingCard==1){
            if(column<columns){
                return false;
            }
        }
        return true;
    }

    /**
     * function that works as getter for the total rows of the duel board.
     * @return rows of the duel board
     */

    public int getRows() {return rows;}

    /**
     * function that works as getter for the colu,ns of the duel board of each side.
     * @return rows of the duel board
     */

     public int getColumns() {return columns;}

    /**
     * function that temporarilly saves the picks of a turn player in each board
     * @param i is the player who made the pick. 0 stands for left side and 1 stands for right side.
     * @param x is row the turn player chose the card
     * @param y is the column of his side of the duel board the turn player chose the card
     */
     public void setSelectedCard_Player_i(int i,int x, int y){
        SelectedCard_Player_i[i][0] = x;
        SelectedCard_Player_i[i][1] = y;
    }

    /**
     * function that works as getter of the pairs of cards remaining in duel board
     * @return the number of cards in play remaining
     */
    public int getNumberOfPairsInPlay() {
        return numberOfPairsInPlay;
    }

    /**
     * This function creates an 1d array with values starting from 0,1,...,n (n belongs in Natural Numbers)
     * where n = rows*columns/sameCopies.
     * @return Returns the 1d array explained above.
     *
     */
    private int[] CreateSerialArray()
    {
        int[] temporaryArray = new int[rows*columns];
        for(int i=0;i<rows*columns;i++)
        {
                temporaryArray[i] = i;
        }

        return temporaryArray;
    }

    /**
     * @param array A 1d integer array
     * Shuffles the element of a given array of integers in a random order.
     * @return Returns the shuffled array.
     */
    private int[] RandomizeArray(int[] array){
        Random rgen = new Random();

        for (int i=0; i<array.length; i++) {
            int randomPosition = rgen.nextInt(array.length);
            int temp = array[i];
            array[i] = array[randomPosition];
            array[randomPosition] = temp;
        }

        return array;
    }

    //parameters can be added, if you want a different alignment of the cards.
    public Duel_Board()
    {
        tables = new Card[2][rows][columns];

        for (int i=0; i<tables.length;i++)
        {
            int[] inputRandomArray = RandomizeArray(CreateSerialArray());
            int currentRow = 0;
            int currentIntegerPosition = 0;
            while(currentRow<rows)
            {
                for (int j=0; j<columns; j++)
                {
                    tables[i][currentRow][j] = new Card(inputRandomArray[currentIntegerPosition]);
                    currentIntegerPosition++;
                }
                currentRow++;
            }
            /*
        int[2], because each card of the board has 2 coordinates
        x and y. No more (yet ;) )
         */
        }

        SelectedCard_Player_i = new int[tables.length][2];

        numberOfPairsInPlay = columns*rows;


    }

    /**
     * this function checks if the 2 card picks are identical. If that's the case, it removes those cards
     * from the duel board and reduces the number of pairs of cards in play by 1. Otherwise, it sets those
     * cards face-down.
     * @return true if the 2 cards that were picked are identical. Otherwise, it returns false.
     */
    public boolean OutcomeOfSelections()
    {
        if (tables[0][SelectedCard_Player_i[0][0]][SelectedCard_Player_i[0][1]].getId() == tables[1][SelectedCard_Player_i[1][0]][SelectedCard_Player_i[1][1]].getId())
        {
            tables[0][SelectedCard_Player_i[0][0]][SelectedCard_Player_i[0][1]] = null;       // it doesnt work (bug). Fixed through GUI
            tables[1][SelectedCard_Player_i[1][0]][SelectedCard_Player_i[1][1]] = null;       // it doesnt work (bug). Fixed through GUI
            numberOfPairsInPlay-=1;
            return true;
            /*
            It should be noted that when this happens, the pairs of the player who drew last
            must increase by 1.
            i.e. Player[i].completedPair();
            where i = player who drew last.
             */
        }
        else
        {
            /*
            Cards are reset to closed.
             */

            tables[0][SelectedCard_Player_i[0][0]][SelectedCard_Player_i[0][1]].setOpen(false);
            tables[1][SelectedCard_Player_i[1][0]][SelectedCard_Player_i[1][1]].setOpen(false);
            return false;
        }
    }

    /**
     * checks if the game with the duel board ended by checking if there are no remaining pairs of cards in play
     * @return true if there are no remaning pairs of cards in play. Otherwise, it returns false.
     */

    public boolean gameOver() {return numberOfPairsInPlay==0;}
}
