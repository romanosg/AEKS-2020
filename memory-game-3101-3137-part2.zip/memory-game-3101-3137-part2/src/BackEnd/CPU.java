/**
 * @author Georgios Romanos
 * @author Konstantinos Stavratis
 * @version 1.1
 * This class represents the player in a CPU behavior. It has functions that help it play the memory game based
 * on the memory game logic and the type of CPU.
 */

package BackEnd;

import java.awt.*;
import java.util.Random;

public class CPU extends Player{

    /**
     * Measures the probability of a CPU memorizing a card.
     */
    private int probability;
    private CPU_Memory[] Hippocampus;
    private int rows;
    private int columns;
    private int sameCopies;
    private Card[][] table;
    private int side;

    /**
     * Constructor of CPU in a normal board match.
     * @param Name of CPU player
     * @param CPU_Type determines whether CPU is Goldfish, Kangaroo or Elephant.
     * @param gameBoard determines the normal board type.
     */
    public CPU(String Name, int CPU_Type, Board gameBoard)
    {
        super(Name);
        if(CPU_Type == 1)
        {
            probability = 0;
        }
        else if(CPU_Type==2)
            {
                probability = 50;
            }

        else{ probability = 100; }

        rows = gameBoard.getRows();
        columns = gameBoard.getColumns();
        sameCopies = gameBoard.getSameCopies();

        table = gameBoard.getTable();

        Hippocampus = new CPU_Memory[(rows*columns)/sameCopies];
        for (int i=0; i<Hippocampus.length;i++)
        {
            Hippocampus[i] = new CPU_Memory(sameCopies);
        }
    }


    /**
     * Constructor of CPU in a duel board match.
     * @param Name of CPU player
     * @param CPU_Type determines whether CPU is Goldfish, Kangaroo or Elephant.
     * @param gameBoard Duel baord.
     * @param side of the duel board (0 left or 1 right).
     */
    public CPU(String Name, int CPU_Type, Duel_Board gameBoard, int side)
    {
        super(Name);
        if(CPU_Type == 1)
        {
            probability = 0;
        }
        else if(CPU_Type==2)
        {
            probability = 50;
        }

        else{ probability = 100; }
        this.side = side;
        rows = gameBoard.getRows();
        columns = gameBoard.getColumns();
        sameCopies = 1;
        table = gameBoard.getTable();
        Hippocampus = new CPU_Memory[(rows*columns)/sameCopies];
        for (int i=0; i<Hippocampus.length;i++)
        {
            Hippocampus[i] = new CPU_Memory(sameCopies);
        }
    }

    /**
     * Function that stores the coordinates and id of a card in the board, according to the CPU's memorizing probability.
     * @param row that the card is in.
     * @param column that the card is in.
     * @param id of card.
     */
    public void memorize(int row, int column, int id)
    {
        Random ran = new Random();
        int potential = ran.nextInt(100);
        if(potential< probability)
        {
            Hippocampus[id].addPoint(row, column);
        }
    }


    /**
     * Makes the CPU choose a set of cards, depending on in custom game mode it is in.
     * @return Set of cards.
     */
    public Point[] pickCard()
    {
        Point[] positions = new Point[sameCopies];
        Random ranPosition = new Random();
        int id;
        for(int j =  0; j < sameCopies; j++) {
            for (int i = 0; i < Hippocampus.length; i++) {
                if (Hippocampus[i].getLength() == sameCopies) {
                    if(!(Hippocampus[i].getisRemoved())) {
                        return Hippocampus[i].getCoordinates();
                    }
                }
            }
            int x,y;
            boolean flag;
            do{
                flag = true;
                x = ranPosition.nextInt(rows);
                y = ranPosition.nextInt(columns);
                if(table[x][y]==null) {
                    flag = false;
                }else if (table[x][y].isOpen()) {
                    flag = false;
                }else{
                    for(int k = 0; k < j; k++){
                        if(((int) Math.round(positions[k].getX()) == x) &&
                                ((int) Math.round(positions[k].getY()) == y)){
                            flag = false;
                        }
                    }
                }
            }while(!flag);
            positions[j] = new Point(x, y);
            id = table[x][y].getId();
            memorize(x, y, id);

        }
        return positions;
    }

    /**
     * Returns one card at random when the CPU plays first in the round.
     * @return one random card.
     */
    public Point pickCardDuelInitiative()
    {
        Random ran = new Random();
        int x,y;
        boolean flag = false;
        do{
            x = ran.nextInt(rows);
            y = ran.nextInt(columns);
            if(table[x][y + side*columns]!=null)
                if(!table[x][y + side*columns].isOpen())
                    flag=true;
        }while(!flag);
        Point toSend = new Point(x,y + side*columns);
        return toSend;
    }


    /**
     * CPU's response to the opponent's picked card.
     * @param opponentID Id of the card the opponent picked.
     * @return card which best "answers" the opponent's pick.
     */
    public Point[] pickCardDuelRespond(int opponentID)
    {
        if(Hippocampus[opponentID].getLength()==sameCopies)
        {
            /*
            If instance will not be needed, since the pair can
            only be chosen once.
             */
            return Hippocampus[opponentID].getCoordinates();
        }
        else
        {
            Random ran = new Random();
            int x,y;
            boolean flag = false;
            do{
                x = ran.nextInt(rows);
                y = ran.nextInt(columns);
                if(table[x][y + side*columns]!=null)
                    if(!table[x][y + side*columns].isOpen())
                        flag=true;
            }while(!flag);

            Point[] toSend = new Point[1];
            toSend[0] = new Point(x,y + side*columns);
            return toSend;
        }
    }

    /**
     * After this function has been called, the CPU consider the id gone from the game board,
     * so as to avoid a null pointer exception.
     * @param id of cards that are no longer in the game board.
     */
    public void considerRemovedCard(int id){
        Hippocampus[id].removed();
    }
}
