/**
 * @author Konstantinos Stavratis
 * @version 1.1
 * This class is used for the highscore file that will be exported at the end of each match.
 * Saves the name and the score of the player, along with getters and setters for each field.
 * Has only 1 constructor, which demands a name and an integer.
 */

package BackEnd;

public class Name_and_Score {

    /**
     * Name of player that is going to be stored in the file.
     */
    public String name;
    /**
     * Score of player that is going to be stored in the file.
     */
    public int score;

    /**
     * Constructor of Name_and_Score
     * @param name name of the player.
     * @param score of the player, depending on the game mode.
     */
    public Name_and_Score(String name,int score)
    {
        this.name = name;
        this.score = score;
    }

    /**
     * @return name of player.
     */
    public String getName() { return name; }

    /**
     * Sets the name of the player, if need be.
     * @param value name that is going to be (re)given to the object.
     */
    public void setName(String value) { name = value;}

    /**
     * Returns score of object.
     * @return score.
     */
    public int getScore(){ return score;}

    /**
     * Sets score of the object, if need be.
     * @param value score of player that will be (re)given.
     */
    public void setScore(int value) {score = value;}

}
