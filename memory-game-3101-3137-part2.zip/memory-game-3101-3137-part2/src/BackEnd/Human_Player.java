package BackEnd;

import java.awt.*;

/**
 * @author Konstantinos Stavratis
 * @version 1.1
 * Simulates a human player. Mostly follows the mother class "Player" 's structure.
 */

public class Human_Player extends Player {

    public void considerRemovedCard(int id){};

    public void memorize(int x, int y, int id){}

    public Point[] pickCard(){ return new Point[0]; }

    public Point pickCardDuelInitiative(){return new Point();}

    public Point[] pickCardDuelRespond(int opponentID){return new Point[0];}

    public Human_Player(){super();}

    public Human_Player(String name) {super(name);}

    //@Override
    /*
    I suppose this is where the UI steps up for the challenge, because
    here we need to ask the player which card he wants.
    If need be, you can remove these, if you think they cannot or don't
    need to be used.
     */
    public int[][] pickCards()
    {
        return new int[0][0];
    }
    public int[] pickCardDuel(int IdOpponentPicked) {return new int[0];}
}
