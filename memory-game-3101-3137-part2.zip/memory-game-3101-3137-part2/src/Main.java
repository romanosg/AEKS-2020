import BackEnd.Highscore_File_Manager;
import BackEnd.Name_and_Score;
import UserInterface.UserInterface;
import UserInterface.MemoryGameApp;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        MemoryGameApp A = new MemoryGameApp();


    }
}
